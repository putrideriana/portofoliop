<?php 
$koneksi = mysqli_connect("localhost", "root", "", "latihan_ukkderiana");