<?php

define('baseurl', 'http://localhost/ujikom_deriana/public');

//DB
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','latihan_ukkderiana');