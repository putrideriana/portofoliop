<?php

define('BASEURL','http://localhost/ujikom_deriana/public');
