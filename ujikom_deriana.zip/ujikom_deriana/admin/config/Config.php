<?php

define('baseurl', 'http://localhost/ujikom_deriana/public');