<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "ukk22_zul";

$koneksi = mysqli_connect($host, $user, $pass, $db);
