<?php

define('baseurl', 'http://localhost/DERIANA/public');