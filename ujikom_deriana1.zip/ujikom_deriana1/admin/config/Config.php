<?php

define('baseurl', 'http://localhost/ujikom_deriana1/public');